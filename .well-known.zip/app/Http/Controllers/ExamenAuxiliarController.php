<?php

namespace App\Http\Controllers;

use App\Models\ExamenAuxiliar;
use Illuminate\Support\Facades\File;
use Illuminate\Http\Request;

class ExamenAuxiliarController extends Controller
{
    public function store(Request $request, $tipo)
    {
        $request->validate([
            'cita_id' => ['required', 'exists:citas,id'],
            'lab_titulo' => ['required', 'string', 'max:255'],
            'lab_file' => ['mimes:pdf,png,jpg,jpeg,doc,docx,xls,xlsx,zip,rar', 'max:10240']
        ]);

        $folder = '';

        switch($tipo) {
            case 1:
                $folder = 'examenes_auxiliares/laboratorios';
                break;
            case 2:
                $folder = 'examenes_auxiliares/imagenes';
                break;
            case 3:
                $folder = 'examenes_auxiliares/otros';
                break;
            case 4:
                $folder = 'examenes_auxiliares/procedimientos';
                break;
            case 5:
                $folder = 'examenes_auxiliares/interconsultas';
                break;
        }

        if ($request->file('lab_file')) {
            $fileName = time().'_'.str_replace('+', '_', $request->lab_file->getClientOriginalName());
            $filePath = $request->file('lab_file')->storeAs($folder, $fileName, 'public');

            ExamenAuxiliar::create([
                'cita_id' => $request->cita_id,
                'tipo' => $tipo, // lab
                'titulo' => $request->lab_titulo,
                'descripcion' => $request->lab_descripcion,
                'url' => '' . $filePath
            ]);
        }
        else {
            ExamenAuxiliar::create([
                'cita_id' => $request->cita_id,
                'tipo' => $tipo, // lab
                'titulo' => $request->lab_titulo,
                'descripcion' => $request->lab_descripcion
            ]);
        }

        return back();
    }

    public function update(Request $request, $id)
    {
        // dd($request);

        $request->validate([
            'lab_edit_titulo' => ['required', 'string', 'max:255'],
            'lab_edit_file' => ['mimes:pdf,png,jpg,jpeg,doc,docx', 'max:2048']
        ]);

        $folder = '';

        $exam_aux = ExamenAuxiliar::find($id);

        switch($exam_aux->tipo) {
            case 1:
                $folder = 'examenes_auxiliares/laboratorios';
                break;
            case 2:
                $folder = 'examenes_auxiliares/imagenes';
                break;
            case 3:
                $folder = 'examenes_auxiliares/otros';
                break;
            case 4:
                $folder = 'examenes_auxiliares/procedimientos';
                break;
            case 5:
                $folder = 'examenes_auxiliares/interconsultas';
                break;
        }

        if ($request->file('lab_edit_file')) {

            //dd($request->file('lab_edit_file'));

            if(File::exists(public_path('storage/' . $exam_aux->url))) {
                File::delete(public_path('storage/' . $exam_aux->url));
            }
            else {
                //dd('File does not exists: ' . 'storage/' . public_path($exam_aux->url));
            }

            $fileName = time().'_'.str_replace('+', '_', $request->lab_edit_file->getClientOriginalName());
            $filePath = $request->file('lab_edit_file')->storeAs($folder, $fileName, 'public');

            $exam_aux->url = '' . $filePath;
        }
        else if ($request->file('lab_edit_file2')) {
            $fileName = time().'_'.str_replace('+', '_', $request->lab_edit_file2->getClientOriginalName());
            $filePath = $request->file('lab_edit_file2')->storeAs($folder, $fileName, 'public');

            $exam_aux->url = '' . $filePath;
        }

        $exam_aux->titulo = $request->lab_edit_titulo;
        $exam_aux->descripcion = $request->lab_edit_descripcion;
        $exam_aux->save();

        return back();
    }

    public function destroy($id)
    {
        $result = ExamenAuxiliar::findOrFail($id);

        if(File::exists(public_path('storage/' . $result->url))) {
            File::delete(public_path('storage/' . $result->url));
        }
        else {
            // dd('File does not exists.' . 'storage/' . public_path($result->url));
        }

        $result->delete();

        return back();
    }
}
