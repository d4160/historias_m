<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Antecedente extends Model
{
    use HasFactory;

    protected $fillable = [
        'paciente_id',
        'fis_prenatales',
        'fis_natal',
        'fis_inmunizaciones',
        'gen_medicamentos',
        'hab_noc_tabaco',
        'hab_noc_oh',
        'hab_noc_drogas',
        'hab_noc_cafe',
        'hab_noc_otros',
        'gin_obs_menarquia',
        'gin_obs_rc',
        'gin_obs_fur',
        'gin_obs_fpp',
        'gin_obs_rs',
        'gin_obs_dismenorrea',
        'gin_obs_g',
        'gin_obs_p',
        'gin_obs_fup',
        'gin_obs_cesareas',
        'gin_obs_ult_pap',
        'gin_obs_mamografia',
        'gin_obs_mac',
        'gin_obs_otros',
        'hepatitis',
        'sd_febril',
        'alergias',
        'tuberculosis',
        'cirugias',
        'hip_arterial',
        'patologicos',
        'familiares',
        'ocupacionales',
        'ram'
    ];

    public function paciente() {
        $this->belongsTo('App\Models\Paciente');
    }
}
