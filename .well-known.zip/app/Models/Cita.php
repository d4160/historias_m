<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Cita extends Model
{
    use HasFactory;

    protected $fillable = [
        'enfermedad_actual_id',
        'paciente_id',
        'funcion_id',
        'examen_id',
        'diagnostico_id',
        'tratamiento_id',
        'sede',
        'fecha_hora'
    ];

    public function enfermedadActual() {
        return $this->belongsTo('App\Models\EnfermedadActual');
    }

    public function paciente() {
        return $this->belongsTo('App\Models\Paciente');
    }

    public function funcion() {
        return $this->belongsTo('App\Models\Funcion');
    }

    public function diagnostico() {
        return $this->belongsTo('App\Models\Diagnostico');
    }

    public function examen() {
        return $this->belongsTo('App\Models\Examen');
    }

    public function examenAuxiliares() {
        return $this->hasMany('App\Models\ExamenAuxiliar');
    }

    public function tratamiento() {
        return $this->belongsTo('App\Models\Tratamiento');
    }

    public function laboratorios() {
        return $this->hasMany('App\Models\ExamenAuxiliar')->where('examen_auxiliares.tipo', '=', 1);
    }

    public function imagenes() {
        return $this->hasMany('App\Models\ExamenAuxiliar')->where('tipo', '=', 2);
    }

    public function otros() {
        return $this->hasMany('App\Models\ExamenAuxiliar')->where('tipo', '=', 3);
    }

    public function procedimientos() {
        return $this->hasMany('App\Models\ExamenAuxiliar')->where('tipo', '=', 4);
    }

    public function interconsultas() {
        return $this->hasMany('App\Models\ExamenAuxiliar')->where('tipo', '=', 5);
    }
}
