<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ClinicStory extends Model
{
    use HasFactory;

    protected $table = "clinic_stories";

    protected $fillable = [
        'user_id',
        'title',
        'description',
        'url'
    ];

    public function patient() {
        $this->belongsTo('App\Models\Paciente');
    }
}
