<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Diagnostico extends Model
{
    use HasFactory;

    protected $fillable = [
        'cita_id',
        'dia_pre_cei101',
        'dia_pre_p1',
        'dia_pre_cei102',
        'dia_pre_p2',
        'dia_pre_cei103',
        'dia_pre_p3',
        'dia_def_cie10',
        'dia_def_d'
    ];

    public function diagnostico() {
        $this->belongsTo('App\Models\Diagnostico');
    }
}
