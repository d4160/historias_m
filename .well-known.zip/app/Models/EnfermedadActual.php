<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EnfermedadActual extends Model
{
    use HasFactory;

    protected $table = 'enfermedad_actuales';

    protected $fillable = [
        'cita_id',
        'seg_tip_informante',
        'tie_enfermedad',
        'for_inicio',
        'sig_sin_principales',
        'rel_cronologico'
    ];

    public function cita() {
        $this->belongsTo('App\Models\Cita');
    }
}
