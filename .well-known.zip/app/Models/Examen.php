<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Examen extends Model
{
    use HasFactory;

    protected $table = 'examenes';

    protected $fillable = [
        'cita_id',
        'exa_fis_est_general',
        'exa_fis_est_conciencia',
        'exa_fis_dirigido'
    ];

    public function cita(){
        $this->belongsTo('App\Models\Cita');
    }
}
