<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ExamenAuxiliar extends Model
{
    use HasFactory;

    protected $table = 'examen_auxiliares';

    protected $fillable = [
        'tipo',
        'cita_id',
        'titulo',
        'descripcion',
        'url'
    ];

    public function cita(){
        $this->belongsTo('App\Models\Cita');
    }
}
