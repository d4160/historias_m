<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Funcion extends Model
{
    use HasFactory;

    protected $table = 'funciones';

    protected $fillable = [
        'cita_id',
        'fun_bio_apetito',
        'fun_bio_sed',
        'fun_bio_sueno',
        'fun_bio_orina',
        'fun_bio_deposiciones',
        'fun_vit_pa',
        'fun_vit_fr',
        'fun_vit_fc',
        'fun_vit_t',
        'fun_vit_peso',
        'fun_vit_talla'
    ];

    public function cita(){
        $this->belongsTo('App\Models\Cita');
    }
}
