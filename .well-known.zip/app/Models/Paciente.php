<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Paciente extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'antecedente_id'
    ];

    public function user() {
        return $this->belongsTo('App\Models\User');
    }

    public function antecedente() {
        return $this->belongsTo('App\Models\Antecedente');
    }

    public function citas() {
        return $this->hasMany('App\Models\Cita')->orderBy('created_at', 'desc');
    }

    public function clinicStories() {
        return $this->hasMany('App\Models\ClinicStory')->orderBy('created_at', 'desc');
    }
}
