<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Tratamiento extends Model
{
    use HasFactory;

    protected $fillable = [
        'cita_id',
        'tra_med_hig_dieteticas',
        'tra_med_preventivos',
        'tra_trans_lugar',
        'tra_trans_hora',
        'tra_des_med_periodo',
        'tra_des_med_dias',
        'tra_fec_pro_cita'
    ];

    public function cita(){
        return $this->belongsTo('App\Models\Cita');
    }

    public function detalles(){
        return $this->hasMany('App\Models\TratamientoDetalle');
    }
}
