<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TratamientoDetalle extends Model
{
    use HasFactory;

    protected $fillable = [
        'tratamiento_id',
        'medicamento',
        'concentracion',
        'dosis',
        'frecuencia',
        'via'
    ];

    public function tratamiento() {
        return $this->belongsTo('App\Models\Tratamiento');
    }
}
