<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var string[]
     */
    protected $fillable = [
        'user_role_id',
        'num_document',
        'first_names',
        'last_names',
        'sexo',
        'estado_civil',
        'raza',
        'religion',
        'fecha_nacimiento',
        'edad',
        'lugar_nac',
        'procedencia_dep',
        'procedencia_prov',
        'procedencia_dis',
        'direccion_actual',
        'grado_inst_ocu',
        'centro_edu_lab',
        'grupo_sanguineo',
        'factor_rh',
        'telefono_fijo',
        'celular',
        'specific_role_id',
        'email',
        'password'
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public function role() {
        return $this->belongsTo('App\Models\UserRole');
    }

    public function getFullNameAttribute() {
        return ucfirst($this->first_names) . ' ' . ucfirst($this->last_names);
    }

    public function isAdmin() {
        return $this->user_role_id > 0 && $this->user_role_id < 5 ? true : false;
    }

    public function isPatient() {
        return $this->user_role_id === 5 ? true : false;
    }

    public function patientId() {
        return Paciente::find($this->specific_role_id)->id;
    }

    public function patient() {
        return Paciente::find($this->specific_role_id);
    }
}
