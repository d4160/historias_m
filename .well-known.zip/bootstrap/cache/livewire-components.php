<?php return array (
  'procedencia' => 'App\\Http\\Livewire\\Procedencia',
);