<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use App\Models\User;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->unsignedSmallInteger('user_role_id')->default(3);
            $table->string('num_document', 50)->unique();
            $table->string('first_names')->nullable();
            $table->string('last_names')->nullable();
            $table->enum('sexo', array('M (Masculino)','F (Femenino)'))->default('F (Femenino)');
            $table->enum('estado_civil', array('S (Soltero)','C (Casado)', 'Co (Conviviente)', 'D (Divorciado)', 'V (Viudo)'))->default('S (Soltero)');
            $table->enum('raza', array('India','Española', 'Negra', 'China', 'Mestiza', 'Otra'))->default('Mestiza');
            // $table->string('raza')->nullable();
            $table->enum('religion', array('Católica','Evangélica', 'Cristiana', 'Agnóstica', 'Atea', 'Otra'))->default('Cristiana');
            // $table->string('religion')->nullable();
            $table->date('fecha_nacimiento')->nullable();
            $table->integer('edad')->default(18);
            $table->string('lugar_nac')->nullable();
            /* dividir procedencia en3: dep, prov, dis */
            $table->string('procedencia_dep', 2)->nullable();
            $table->string('procedencia_prov', 4)->nullable();
            $table->string('procedencia_dis', 6)->nullable();
            $table->string('direccion_actual')->nullable();
            $table->enum('grado_inst_ocu', array('Estudiante primaria', 'Estudiante segundaria', 'Estudiante técnico', 'Estudiante universitario', 'Independiente', 'Dependiente'))->default('Independiente');
            // $table->string('grado_inst_ocu')->nullable();
            $table->string('centro_edu_lab')->nullable();
            $table->enum('grupo_sanguineo', array('O','A', 'AB', 'B', 'NR'))->nullable();
            $table->enum('factor_rh', array('+','-', 'NR'))->nullable();
            $table->string('telefono_fijo')->nullable();
            $table->string('celular')->nullable();
            $table->unsignedBigInteger('specific_role_id')->nullable();
            $table->string('email')->unique()->nullable();
            $table->timestamp('email_verified_at')->nullable();
            $table->string('password');
            $table->rememberToken();
            $table->timestamps();

            $table->foreign('user_role_id')->references('id')->on('user_roles')->cascadeOnDelete();
        });

        $this->postCreate(array([
            'user_role_id' => '1',
            'num_document' => '48238255',
            'first_names' => 'Diego',
            'last_names' => 'Fernandez',
            'email' => 'diego.ale.fernandez.rivera@gmail.com',
            'password' => bcrypt('48238255')
        ]));

        $this->postCreate(array([
            'user_role_id' => '2',
            'num_document' => 'jrlozanoa@gmail.com',
            'first_names' => 'Jinn Ronal',
            'last_names' => 'Lozano Antonio',
            'email' => 'jrlozanoa@gmail.com',
            'password' => bcrypt('jrlozanoa@gmail.com')
        ]));

        $this->postCreate(array([
            'user_role_id' => '4',
            'num_document' => 'reumainnova@gmail.com',
            'first_names' => 'Asistente',
            'last_names' => 'Administrativo',
            'email' => 'reumainnova@gmail.com',
            'password' => bcrypt('reumainnova@gmail.com')
        ]));
    }

    private function postCreate(array $users)  {
        foreach ($users as $user) {
            $model = new User($user);
            $model->save();
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
