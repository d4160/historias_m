<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAntecedentesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('antecedentes', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('paciente_id');
            $table->text('fis_prenatales')->nullable(); // 1000, textarea
            $table->text('fis_natal')->nullable(); // 1000, textarea
            $table->text('fis_inmunizaciones')->nullable(); // 1000, textarea
            $table->text('gen_medicamentos')->nullable(); // 1000, textarea
            $table->boolean('hab_noc_tabaco')->nullable();
            $table->boolean('hab_noc_oh')->nullable();
            $table->boolean('hab_noc_drogas')->nullable();
            $table->boolean('hab_noc_cafe')->nullable();
            $table->text('hab_noc_otros')->nullable(); // 1000, textarea
            $table->text('gin_obs_menarquia')->nullable(); // 1000, textarea
            $table->text('gin_obs_rc')->nullable(); // 1000, textarea
            $table->text('gin_obs_fur')->nullable(); // 1000, textarea
            //$table->text('gin_obs_fpp')->nullable(); // 1000, textarea
            //$table->text('gin_obs_rs')->nullable(); // 1000, textarea
            $table->boolean('gin_obs_dismenorrea')->nullable();
            $table->text('gin_obs_g')->nullable(); // 1000, textarea
            $table->text('gin_obs_p')->nullable(); // 1000, textarea
            //$table->text('gin_obs_fup')->nullable(); // 1000, textarea
            $table->text('gin_obs_cesareas')->nullable(); // 1000, textarea
            $table->text('gin_obs_ult_pap')->nullable(); // 1000, textarea
            $table->text('gin_obs_mamografia')->nullable(); // 1000, textarea
            $table->text('gin_obs_mac')->nullable(); // 1000, textarea
            /* NEGRITA OTROS */
            $table->text('cirugias')->nullable();
            $table->text('gin_obs_otros')->nullable(); // 1000, textarea
            $table->boolean('hepatitis')->nullable();
            $table->boolean('sd_febril')->nullable();
            $table->boolean('alergias')->nullable();
            $table->boolean('tuberculosis')->nullable();
            // $table->boolean('cirugias')->nullable();
            $table->boolean('hip_arterial')->nullable();
            $table->text('patologicos')->nullable(); // 1000, textarea
            $table->text('familiares')->nullable(); // 1000, textarea
            $table->text('ocupacionales')->nullable(); // 1000, textarea
            $table->boolean('ram')->nullable();
            $table->text('ram_descripcion')->nullable();

            $table->timestamps();

            $table->foreign('paciente_id')->references('id')->on('pacientes')->cascadeOnDelete();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('antecedentes');
    }
}
