<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCitasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('citas', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('paciente_id');
            $table->unsignedBigInteger('enfermedad_actual_id')->nullable();
            $table->unsignedBigInteger('funcion_id')->nullable();
            $table->unsignedBigInteger('diagnostico_id')->nullable();
            $table->unsignedBigInteger('examen_id')->nullable();
            $table->unsignedBigInteger('tratamiento_id')->nullable();
            $table->string('sede');
            $table->dateTime('fecha_hora');
            // nuevo campo, sede de atencion
            $table->timestamps();

            // $table->foreign('enfermedad_actual_id')->references('id')->on('enfermedad_actuales');
            // $table->foreign('funcion_id')->references('id')->on('funciones');
            // $table->foreign('tratamiento_id')->references('id')->on('tratamientos');
            // $table->foreign('examen_id')->references('id')->on('examenes');
            // $table->foreign('diagnostico_id')->references('id')->on('diagnosticos');
            $table->foreign('paciente_id')->references('id')->on('pacientes')->cascadeOnDelete();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('citas');
    }
}
