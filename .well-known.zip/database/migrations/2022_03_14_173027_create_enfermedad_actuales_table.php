<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateEnfermedadActualesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('enfermedad_actuales', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('cita_id')->nullable();
            $table->enum('seg_tip_informante', array('Directa', 'Indirecta', 'Mixta'))->nullable();
            $table->smallInteger('tie_enfermedad')->nullable();
            $table->string('for_inicio', 1000)->nullable(); // 1000 textareea
            $table->string('sig_sin_principales', 1000)->nullable(); // 1000 textareea
            $table->text('rel_cronologico')->nullable();

            $table->timestamps();

            $table->foreign('cita_id')->references('id')->on('citas')->cascadeOnDelete();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('enfermedad_actuales');
    }
}
