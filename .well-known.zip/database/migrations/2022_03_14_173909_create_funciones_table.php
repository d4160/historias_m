<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateFuncionesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('funciones', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('cita_id')->nullable();
            $table->enum('fun_bio_apetito', array('N', 'D', 'A'))->nullable();
            $table->enum('fun_bio_sed', array('N', 'D', 'A'))->nullable();
            $table->enum('fun_bio_sueno', array('N', 'D', 'A'))->nullable();
            $table->enum('fun_bio_orina', array('N', 'D', 'A'))->nullable();
            $table->enum('fun_bio_deposiciones', array('N', 'D', 'A'))->nullable();
            $table->string('fun_vit_pa', 7)->nullable(); // #/#
            $table->decimal('fun_vit_fr')->nullable(); // #
            $table->decimal('fun_vit_fc')->nullable(); // #
            $table->decimal('fun_vit_t')->nullable(); // #
            $table->decimal('fun_vit_peso')->nullable(); // #
            $table->decimal('fun_vit_talla')->nullable(); // #
            $table->decimal('fun_vit_imc')->nullable();

            $table->timestamps();

            $table->foreign('cita_id')->references('id')->on('citas')->cascadeOnDelete();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('funciones');
    }
}
