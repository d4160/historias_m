<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDiagnosticosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('diagnosticos', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('cita_id')->nullable();
            $table->string('dia_pre_cei101')->nullable(); // espacio a mitad
            $table->string('dia_pre_p1')->nullable(); // espacio complementario
            $table->string('dia_pre_cei102')->nullable();
            $table->string('dia_pre_p2')->nullable();
            $table->string('dia_pre_cei103')->nullable();
            $table->string('dia_pre_p3')->nullable();
            $table->string('dia_def_cie10')->nullable();
            $table->string('dia_def_d')->nullable();

            $table->timestamps();

            $table->foreign('cita_id')->references('id')->on('citas')->cascadeOnDelete();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('diagnosticos');
    }
}
