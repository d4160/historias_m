<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTratamientosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tratamientos', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('cita_id')->nullable();
            $table->string('tra_med_hig_dieteticas', 1000)->nullable(); // 1000, textarea...
            $table->string('tra_med_preventivos', 1000)->nullable();
            $table->string('tra_trans_lugar')->nullable();
            $table->time('tra_trans_hora')->nullable();
            $table->string('tra_des_med_periodo', 1000)->nullable();
            $table->unsignedSmallInteger('tra_des_med_dias')->nullable();
            $table->date('tra_fec_pro_cita')->nullable();

            $table->timestamps();
            $table->foreign('cita_id')->references('id')->on('citas')->cascadeOnDelete();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tratamientos');
    }
}
