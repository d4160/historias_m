<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTratamientoDetallesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tratamiento_detalles', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('tratamiento_id');
            //$table->integer('numero')->nullable();
            $table->string('medicamento')->nullable();
            $table->string('concentracion')->nullable();
            $table->string('dosis')->nullable();
            $table->string('frecuencia')->nullable();
            $table->string('via')->nullable();

            $table->timestamps();
            $table->foreign('tratamiento_id')->references('id')->on('tratamientos')->cascadeOnDelete();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tratamiento_detalles');
    }
}
