<x-layouts.admin title="Reumainnova - Nuevo paciente" bodyTitle="Nuevo paciente">
    <x-slot name="styles">
        <link rel="stylesheet" type="text/css" href="{{ asset('plugins/table/datatable/datatables.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/forms/theme-checkbox-radio.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ asset('plugins/table/datatable/dt-global_style.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ asset('plugins/table/datatable/custom_dt_custom.css') }}">
        <link href="{{ asset('plugins/flatpickr/flatpickr.css') }}" rel="stylesheet" type="text/css">

        @livewireStyles
    </x-slot>

    <div class="row layout-top-spacing layout-spacing">
        <div class="col-lg-12">
            <div class="statbox widget box box-shadow">

                <div class="widget-header">

                    <!-- Validation Errors -->
                    <x-auth-validation-errors class="m-4" :errors="$errors" />

                    <form class="m-3 mt-4 mb-4" method="POST" action="{{ route('patients.store') }}">
                        @csrf

                        <div class="mb-4 row">
                            <div class="col">
                                <label for="num_document">DNI o CE</label>
                                <input id="num_document" name="num_document" type="text" class="form-control" placeholder="77777777" value="{{ old('num_document') }}" required autofocus minlength="8" maxlength="11">
                            </div>
                            <div class="col">
                                <label for="next_id">Código de paciente</label>
                                <input id="next_id" name="next_id" type="text" class="form-control" placeholder="" value="@php(printf("%06d", $paciente_next_id))" readonly>
                            </div>
                            {{--  <div class="col">
                                <label for="num_document_confirmation">Confirme Nº documento</label>
                                <input id="num_document_confirmation" name="num_document_confirmation" type="text" class="form-control" placeholder="" value="{{ old('num_document_confirmation') }}" required minlength="8" maxlength="11">
                            </div>  --}}
                        </div>
                        <div class="mb-4 row">
                            <div class="col">
                                <label for="first_names">Nombres</label>
                                <input id="first_names" name="first_names" type="text" class="form-control" placeholder="" value="{{ old('first_names') }}" required>
                            </div>
                            <div class="col">
                                <label for="last_names">Apellidos</label>
                                <input id="last_names" name="last_names" type="text" class="form-control" placeholder="" value="{{ old('last_names') }}" required>
                            </div>
                        </div>

                        <div class="mb-4 row">
                            <div class="col">
                                <label for="sexo">Sexo</label>
                                {{ Form::select('sexo', ['M (Masculino)' => 'M (Masculino)', 'F (Femenino)' => 'F (Femenino)'], old('sexo'), ['id' => 'sexo', 'class' => 'form-control', 'required' => 'required']) }}
                            </div>
                            <div class="col">
                                <label for="estado_civil">Estado Civil</label>
                                {{ Form::select('estado_civil', ['S (Soltero)' => 'S (Soltero)', 'C (Casado)' => 'C (Casado)', 'Co (Conviviente)' => 'Co (Conviviente)', 'D (Divorciado)' => 'D (Divorciado)', 'V (Viudo)' => 'V (Viudo)'], old('estado_civil'), ['id' => 'estado_civil', 'class' => 'form-control', 'required' => 'required']) }}
                            </div>
                        </div>

                        <div class="mb-4 row">
                            <div class="col">
                                <label for="raza">Raza</label>
                                {{ Form::select('raza', ['India' => 'India', 'Española' => 'Española', 'Negra' => 'Negra', 'China' => 'China', 'Mestiza' => 'Mestiza', 'Otra' => 'Otra'], old('raza', 'Mestiza'), ['id' => 'raza', 'class' => 'form-control', 'required' => 'required']) }}
                            </div>
                            <div class="col">
                                <label for="religion">Religión</label>
                                {{ Form::select('religion', ['Católica' => 'Católica', 'Evangélica' => 'Evangélica', 'Cristiana' => 'Cristiana', 'Agnóstica' => 'Agnóstica', 'Atea' => 'Atea', 'Otra' => 'Otra', 'No sabe' => 'No sabe'], old('religion', 'Cristiana'), ['id' => 'religion', 'class' => 'form-control', 'required' => 'required']) }}
                            </div>
                        </div>

                        <div class="mb-4 row">
                            <div class="col">
                                <label for="fecha_nacimiento">Fecha de nacimiento</label>
                                <input id="fecha_nacimiento" name="fecha_nacimiento" value="{{ old('fecha_nacimiento') }}" class="form-control" type="text" placeholder="" readonly="readonly" required>
                            </div>
                            <div class="col">
                                <label for="edad">Edad</label>
                                <input id="edad" name="edad" type="text" class="form-control" placeholder="" value="" readonly required>
                            </div>
                        </div>

                        <div class="mb-4 row">
                            <div class="col">
                                <label for="lugar_nac">Lugar de nacimiento</label>
                                <input id="lugar_nac" name="lugar_nac" type="text" class="form-control" placeholder="" value="{{ old('lugar_nac') }}">
                            </div>
                        </div>

                        <livewire:procedencia />

                        <div class="mb-4 row">
                            <div class="col">
                                <label for="direccion_actual">Dirección actual</label>
                                <input id="direccion_actual" name="direccion_actual" type="text" class="form-control" placeholder="" value="{{ old('direccion_actual') }}" required>
                            </div>
                        </div>

                        <div class="mb-4 row">
                            <div class="col">
                                <label for="grado_inst_ocu">Grado de instrucción/ocupación</label>
                                {{ Form::select('grado_inst_ocu', ['Estudiante primaria' => 'Estudiante primaria', 'Estudiante segundaria' => 'Estudiante segundaria', 'Estudiante técnico' => 'Estudiante técnico', 'Estudiante universitario' => 'Estudiante universitario', 'Independiente' => 'Independiente', 'Dependiente' => 'Dependiente'], old('grado_inst_ocu'), ['id' => 'grado_inst_ocu', 'class' => 'form-control', 'required' => 'required']) }}
                            </div>
                            <div class="col">
                                <label for="centro_edu_lab">Centro educativo/laboral</label>
                                <input id="centro_edu_lab" name="centro_edu_lab" type="text" class="form-control" placeholder="" value="{{ old('centro_edu_lab') }}">
                            </div>
                        </div>

                        <div class="mb-4 row">
                            <div class="col">
                                <label for="grupo_sanguineo">Grupo sanguíneo</label>
                                <select id="grupo_sanguineo" name="grupo_sanguineo" class="form-control" value="{{ old('grupo_sanguineo') }}" required>
                                    <option>O</option>
                                    <option>A</option>
                                    <option>AB</option>
                                    <option>B</option>
                                    <option>NR</option>
                                </select>
                            </div>
                            <div class="col">
                                <label for="factor_rh">Factor Rh</label>
                                <select id="factor_rh" name="factor_rh" value="{{ old('factor_rh') }}" class="form-control" required>
                                    <option>+</option>
                                    <option>-</option>
                                    <option>NR</option>
                                </select>
                            </div>
                        </div>

                        <div class="mb-4 row">
                            <div class="col">
                                <label for="telefono_fijo">Teléfono fijo</label>
                                <input id="telefono_fijo" name="telefono_fijo" type="text" class="form-control" placeholder="" value="{{ old('telefono_fijo') }}">
                            </div>
                            <div class="col">
                                <label for="celular">Celular</label>
                                <input id="celular" name="celular" type="text" class="form-control" placeholder="" value="{{ old('celular') }}">
                            </div>
                        </div>

                        <div class="mb-4 row">
                            <div class="col">
                                <label for="email">Correo Electrónico</label>
                                <input id="email" name="email" type="text" class="form-control" placeholder="" value="{{ old('email') }}">
                            </div>
                        </div>

                        <input type="submit" id="btnSubmit" onclick="" class="btn btn-primary" value="Guardar">
                    </form>
                </div>
            </div>
        </div>
    </div>

    <x-slot name="scripts">
        <script src="{{ asset('plugins/flatpickr/flatpickr.js') }}"></script>
        <script src="{{ asset('plugins/input-mask/jquery.inputmask.bundle.min.js') }}"></script>
        <script src="{{ asset('plugins/input-mask/input-mask.js') }}"></script>
        <script src="{{ asset('assets/js/date-util.js') }}"></script>
        <script>
            $(() => {
                var f1 = flatpickr(document.getElementById('fecha_nacimiento'), {
                    maxDate: GetTodayDate()
                });

                $("#email").inputmask(
                    {
                        mask:"*{1,31}[.*{1,31}][.*{1,31}][.*{1,31}]@*{1,31}[.*{2,6}][.*{1,2}]",
                        greedy:!1,onBeforePaste:function(m,a){return(m=m.toLowerCase()).replace("mailto:","")},
                        definitions:{"*":
                            {
                                validator:"[0-9A-Za-z!#$%&'*+/=?^_`{|}~-]",
                                cardinality:1,
                                casing:"lower"
                            }
                        }
                    }
                )
            });

            $('#btnSubmit').click(function(e){
                e.preventDefault();
                if(this.form.reportValidity()){
                    $(this).prop('disabled',true);
                    this.style.setProperty( 'color', 'black', 'important' );
                    $(this).val('Guardando...');
                    this.form.submit();
                }
            });

            CalculateAge('#fecha_nacimiento', '#edad');

        </script>

        @livewireScripts
    </x-slot>

</x-layouts.admin>
