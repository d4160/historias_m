<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layouts.admin','data' => ['title' => 'Reumainnova - Detalle de paciente','bodyTitle' => 'Datos del paciente']]); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => 'Reumainnova - Detalle de paciente','bodyTitle' => 'Datos del paciente']); ?>
     <?php $__env->slot('styles', null, []); ?> 
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('plugins/table/datatable/datatables.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/forms/theme-checkbox-radio.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('plugins/table/datatable/dt-global_style.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('plugins/table/datatable/custom_dt_custom.css')); ?>">
        <link href="<?php echo e(asset('plugins/flatpickr/flatpickr.css')); ?>" rel="stylesheet" type="text/css">
     <?php $__env->endSlot(); ?>

    <?php echo $__env->make('results.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('results.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="row layout-top-spacing layout-spacing">
        <div class="col-lg-12">
            <div class="statbox widget box box-shadow">

                <div class="widget-header">

                    <?php if(count($errors) > 0): ?>
                        <div><?php echo e($errors); ?></div>
                    <?php endif; ?>

                    <form class="m-3 mt-4 mb-4" method="POST" action="<?php echo e(route('patients.update', $patient_id)); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="mb-4 row">
                            <div class="col">
                                <label for="num_document">DNI o CE</label>
                                <input id="num_document" name="num_document" type="text" class="form-control" placeholder="77777777" value="<?php echo e($patient->num_document); ?>" required autofocus minlength="8" maxlength="11">
                            </div>
                            
                        </div>
                        <div class="mb-4 row">
                            <div class="col">
                                <label for="first_names">Nombres</label>
                                <input id="first_names" name="first_names" type="text" class="form-control" placeholder="" value="<?php echo e($patient->first_names); ?>" required>
                            </div>
                            <div class="col">
                                <label for="last_names">Apellidos</label>
                                <input id="last_names" name="last_names" type="text" class="form-control" placeholder="" value="<?php echo e($patient->last_names); ?>" required>
                            </div>
                        </div>

                        <div class="mb-4 row">
                            <div class="col">
                                <label for="sexo">Sexo</label>
                                <?php echo e(Form::select('sexo', ['M (Masculino)' => 'M (Masculino)', 'F (Femenino)' => 'F (Femenino)'], $patient->sexo, ['id' => 'sexo', 'class' => 'form-control', 'required' => 'required'])); ?>

                            </div>
                            <div class="col">
                                <label for="estado_civil">Estado Civil</label>
                                <?php echo e(Form::select('estado_civil', ['S (Soltero)' => 'S (Soltero)', 'C (Casado)' => 'C (Casado)', 'Co (Conviviente)' => 'Co (Conviviente)', 'D (Divorciado)' => 'D (Divorciado)', 'V (Soltero)' => 'V (Soltero)'], $patient->estado_civil, ['id' => 'estado_civil', 'class' => 'form-control', 'required' => 'required'])); ?>

                            </div>
                        </div>

                        <div class="mb-4 row">
                            <div class="col">
                                <label for="raza">Raza</label>
                                <input id="raza" name="raza" type="text" class="form-control" placeholder="" value="<?php echo e($patient->raza); ?>" required>
                            </div>
                            <div class="col">
                                <label for="religion">Religión</label>
                                <input id="religion" name="religion" type="text" class="form-control" placeholder="" value="<?php echo e($patient->religion); ?>" required>
                            </div>
                        </div>

                        <div class="mb-4 row">
                            <div class="col">
                                <label for="fecha_nacimiento">Fecha de nacimiento</label>
                                <input id="fecha_nacimiento" name="fecha_nacimiento" value="<?php echo e($patient->fecha_nacimiento); ?>" class="form-control" type="text" placeholder="" readonly="readonly">
                            </div>
                            <div class="col">
                                <label for="edad">Edad</label>
                                <input id="edad" name="edad" type="text" class="form-control" placeholder="" value="<?php echo e($patient->edad); ?>" readonly>
                            </div>
                        </div>

                        <div class="mb-4 row">
                            <div class="col">
                                <label for="lugar_nac">Lugar de nacimiento</label>
                                <input id="lugar_nac" name="lugar_nac" type="text" class="form-control" placeholder="" value="<?php echo e($patient->lugar_nac); ?>" required>
                            </div>
                            <div class="col">
                                <label for="procedencia">Procedencia</label>
                                <input id="procedencia" name="procedencia" type="text" class="form-control" placeholder="" value="<?php echo e($patient->procedencia); ?>" required>
                            </div>
                        </div>

                        <div class="mb-4 row">
                            <div class="col">
                                <label for="direccion_actual">Dirección actual</label>
                                <input id="direccion_actual" name="direccion_actual" type="text" class="form-control" placeholder="" value="<?php echo e($patient->direccion_actual); ?>" required>
                            </div>
                        </div>

                        <div class="mb-4 row">
                            <div class="col">
                                <label for="grado_inst_ocu">Grado de instrucción/ocupación</label>
                                <input id="grado_inst_ocu" name="grado_inst_ocu" type="text" class="form-control" placeholder="" value="<?php echo e($patient->grado_inst_ocu); ?>" required>
                            </div>
                            <div class="col">
                                <label for="centro_edu_lab">Centro educativo/laboral</label>
                                <input id="centro_edu_lab" name="centro_edu_lab" type="text" class="form-control" placeholder="" value="<?php echo e($patient->centro_edu_lab); ?>" required>
                            </div>
                        </div>

                        <div class="mb-4 row">
                            <div class="col">
                                <label for="grupo_sanguineo">Grupo sanguíneo</label>
                                <?php echo e(Form::select('grupo_sanguineo', ['O' => 'O', 'A' => 'A', 'AB' => 'AB', 'B' => 'B', 'NR' => 'NR'], $patient->grupo_sanguineo, ['id' => 'grupo_sanguineo', 'class' => 'form-control', 'required' => 'required'])); ?>


                                
                            </div>
                            <div class="col">
                                <label for="factor_rh">Factor Rh</label>
                                <?php echo e(Form::select('factor_rh', ['+' => '+', '-' => '-', 'NR' => 'NR'], $patient->factor_rh, ['id' => 'factor_rh', 'class' => 'form-control', 'required' => 'required'])); ?>

                            </div>
                        </div>

                        <div class="mb-4 row">
                            <div class="col">
                                <label for="telefono_fijo">Teléfono fijo</label>
                                <input id="telefono_fijo" name="telefono_fijo" type="text" class="form-control" placeholder="" value="<?php echo e($patient->telefono_fijo); ?>" required>
                            </div>
                            <div class="col">
                                <label for="celular">Celular</label>
                                <input id="celular" name="celular" type="text" class="form-control" placeholder="" value="<?php echo e($patient->celular); ?>" required>
                            </div>
                        </div>

                        <div class="mb-4 row">
                            <div class="col">
                                <label for="email">Correo Electrónico</label>
                                <input id="email" name="email" type="text" class="form-control" placeholder="" value="<?php echo e($patient->email); ?>" required>
                            </div>
                        </div>

                        <input type="submit" id="btnSubmit" class="btn btn-primary" value="Guardar">
                    </form>
                </div>

            </div>
        </div>
    </div>

    <div class="page-header">
        <div class="page-title">
            <h3>Antecedentes</h3>
        </div>
    </div>

    <div class="row layout-top-spacing layout-spacing">
        <div class="col-lg-12">
            <div class="statbox widget box box-shadow">

                <div class="widget-header">

                    <?php if(count($errors) > 0): ?>
                        <div><?php echo e($errors); ?></div>
                    <?php endif; ?>

                    <form class="m-3 mt-4 mb-4" method="POST" action="<?php echo e(route('antecedentes.save', $patient_id)); ?>">
                        <?php echo csrf_field(); ?>

                        <label style="font-weight: bold; color: black; font-size: 17px;">FISIOLÓGICOS</label>

                        <div class="mb-4 row">
                            <div class="col">
                                <label for="fis_prenatales">Prenatales</label>
                                <textarea id="fis_prenatales" name="fis_prenatales" type="text" class="form-control" placeholder="" required><?php echo e($antecedente ? $antecedente->fis_prenatales : old('fis_prenatales')); ?></textarea>
                            </div>
                        </div>

                        <div class="mb-4 row">
                            <div class="col">
                                <label for="fis_natal">Parto</label>
                                <textarea id="fis_natal" name="fis_natal" type="text" class="form-control" placeholder="" required><?php echo e($antecedente ? $antecedente->fis_natal : old('fis_natal')); ?></textarea>
                            </div>
                        </div>

                        <div class="mb-4 row">
                            <div class="col">
                                <label for="fis_inmunizaciones">Inmunizaciones</label>
                                <textarea id="fis_inmunizaciones" name="fis_inmunizaciones" type="text" class="form-control" placeholder="" required><?php echo e($antecedente ? $antecedente->fis_inmunizaciones : old('fis_inmunizaciones')); ?></textarea>
                            </div>
                        </div>

                        <label style="font-weight: bold; color: black; font-size: 17px;">GENERALES</label>

                        <div class="mb-4 row">
                            <div class="col">
                                <label for="gen_medicamentos">Medicamentos</label>
                                <textarea id="gen_medicamentos" name="gen_medicamentos" type="text" class="form-control" placeholder="" required><?php echo e($antecedente ? $antecedente->gen_medicamentos : old('gen_medicamentos')); ?></textarea>
                            </div>
                        </div>

                        <label style="font-weight: bold; color: darkgray; font-size: 16px;">Hábitos Nocivos</label>

                        <div class="mb-4 row">
                            <div class="col">
                                <label for="hab_noc_tabaco">Tabaco</label>
                                <?php echo e(Form::select('hab_noc_tabaco', ['0' => 'No', '1' => 'Sí'], $antecedente ? $antecedente->hab_noc_tabaco : old('hab_noc_tabaco'), ['id' => 'hab_noc_tabaco', 'class' => 'form-control', 'required' => 'required'])); ?>

                            </div>
                            <div class="col">
                                <label for="hab_noc_oh">OH</label>
                                <?php echo e(Form::select('hab_noc_oh', ['0' => 'No', '1' => 'Sí'], $antecedente ? $antecedente->hab_noc_oh : old('hab_noc_oh'), ['id' => 'hab_noc_oh', 'class' => 'form-control', 'required' => 'required'])); ?>

                            </div>
                            <div class="col">
                                <label for="hab_noc_drogas">Drogas</label>
                                <?php echo e(Form::select('hab_noc_drogas', ['0' => 'No', '1' => 'Sí'], $antecedente ? $antecedente->hab_noc_drogas : old('hab_noc_drogas'), ['id' => 'hab_noc_drogas', 'class' => 'form-control', 'required' => 'required'])); ?>

                            </div>
                            <div class="col">
                                <label for="hab_noc_cafe">Café</label>
                                <?php echo e(Form::select('hab_noc_cafe', ['0' => 'No', '1' => 'Sí'], $antecedente ? $antecedente->hab_noc_cafe : old('hab_noc_cafe'), ['id' => 'hab_noc_cafe', 'class' => 'form-control', 'required' => 'required'])); ?>

                            </div>
                        </div>

                        <div class="mb-4 row">
                            <div class="col">
                                <label for="hab_noc_otros">Otros</label>
                                <textarea id="hab_noc_otros" name="hab_noc_otros" type="text" class="form-control" placeholder="" required><?php echo e($antecedente ? $antecedente->hab_noc_otros : old('hab_noc_otros')); ?></textarea>
                            </div>
                        </div>

                        <label style="font-weight: bold; color: black; font-size: 17px;">GINECO-OBSTÉTRICOS</label>

                        <div class="mb-4 row">
                            <div class="col">
                                <label for="gin_obs_menarquia">Menarquía</label>
                                <textarea id="gin_obs_menarquia" name="gin_obs_menarquia" type="text" class="form-control" placeholder="" required><?php echo e($antecedente ? $antecedente->gin_obs_menarquia : old('gin_obs_menarquia')); ?></textarea>
                            </div>
                            <div class="col">
                                <label for="gin_obs_rc">RC</label>
                                <textarea id="gin_obs_rc" name="gin_obs_rc" type="text" class="form-control" placeholder="" required><?php echo e($antecedente ? $antecedente->gin_obs_rc : old('gin_obs_rc')); ?></textarea>
                            </div>
                            <div class="col">
                                <label for="gin_obs_fur">FUR</label>
                                <textarea id="gin_obs_fur" name="gin_obs_fur" type="text" class="form-control" placeholder="" required><?php echo e($antecedente ? $antecedente->gin_obs_fur : old('gin_obs_fur')); ?></textarea>
                            </div>
                        </div>

                        <div class="mb-4 row">
                            <div class="col">
                                <label for="gin_obs_fpp">FPP</label>
                                <textarea id="gin_obs_fpp" name="gin_obs_fpp" type="text" class="form-control" placeholder="" required><?php echo e($antecedente ? $antecedente->gin_obs_fpp : old('gin_obs_fpp')); ?></textarea>
                            </div>
                            <div class="col">
                                <label for="gin_obs_rs">RS</label>
                                <textarea id="gin_obs_rs" name="gin_obs_rs" type="text" class="form-control" placeholder="" required><?php echo e($antecedente ? $antecedente->gin_obs_rs : old('gin_obs_rs')); ?></textarea>
                            </div>
                            <div class="col">
                                <label for="gin_obs_dismenorrea">Dismenorrea</label>
                                <?php echo e(Form::select('gin_obs_dismenorrea', ['0' => 'No', '1' => 'Sí'], $antecedente ? $antecedente->gin_obs_dismenorrea : old('gin_obs_dismenorrea'), ['id' => 'gin_obs_dismenorrea', 'class' => 'form-control', 'required' => 'required'])); ?>

                            </div>
                        </div>

                        <div class="mb-4 row">
                            <div class="col">
                                <label for="gin_obs_g">G</label>
                                <textarea id="gin_obs_g" name="gin_obs_g" type="text" class="form-control" placeholder="" required><?php echo e($antecedente ? $antecedente->gin_obs_g : old('gin_obs_g')); ?></textarea>
                            </div>
                            <div class="col">
                                <label for="gin_obs_p">P</label>
                                <textarea id="gin_obs_p" name="gin_obs_p" type="text" class="form-control" placeholder="" required><?php echo e($antecedente ? $antecedente->gin_obs_p : old('gin_obs_p')); ?></textarea>
                            </div>
                            <div class="col">
                                <label for="gin_obs_fup">FUP</label>
                                <textarea id="gin_obs_fup" name="gin_obs_fup" type="text" class="form-control" placeholder="" required><?php echo e($antecedente ? $antecedente->gin_obs_fup : old('gin_obs_fup')); ?></textarea>
                            </div>
                            <div class="col">
                                <label for="gin_obs_cesareas">Cesáreas</label>
                                <textarea id="gin_obs_cesareas" name="gin_obs_cesareas" type="text" class="form-control" placeholder="" required><?php echo e($antecedente ? $antecedente->gin_obs_cesareas : old('gin_obs_cesareas')); ?></textarea>
                            </div>
                        </div>

                        <div class="mb-4 row">
                            <div class="col">
                                <label for="gin_obs_ult_pap">Último PAP</label>
                                <textarea id="gin_obs_ult_pap" name="gin_obs_ult_pap" type="text" class="form-control" placeholder="" required><?php echo e($antecedente ? $antecedente->gin_obs_ult_pap : old('gin_obs_ult_pap')); ?></textarea>
                            </div>
                            <div class="col">
                                <label for="gin_obs_mamografia">Mamografía</label>
                                <textarea id="gin_obs_mamografia" name="gin_obs_mamografia" type="text" class="form-control" placeholder="" required><?php echo e($antecedente ? $antecedente->gin_obs_mamografia : old('gin_obs_mamografia')); ?></textarea>
                            </div>
                            <div class="col">
                                <label for="gin_obs_mac">MAC</label>
                                <textarea id="gin_obs_mac" name="gin_obs_mac" type="text" class="form-control" placeholder="" required><?php echo e($antecedente ? $antecedente->gin_obs_mac : old('gin_obs_mac')); ?></textarea>
                            </div>
                        </div>

                        <div class="mb-4 row">
                            <div class="col">
                                <label for="gin_obs_otros" style="font-weight: bold; color: black; font-size: 17px;">Otros</label>
                                <textarea id="gin_obs_otros" name="gin_obs_otros" type="text" class="form-control" placeholder="" required><?php echo e($antecedente ? $antecedente->gin_obs_otros : old('gin_obs_otros')); ?></textarea>
                            </div>
                        </div>

                        <div class="mb-4 row">
                            <div class="col">
                                <label for="hepatitis">Hepatitis</label>
                                <?php echo e(Form::select('hepatitis', ['0' => 'No', '1' => 'Sí'], $antecedente ? $antecedente->hepatitis : old('hepatitis'), ['id' => 'hepatitis', 'class' => 'form-control', 'required' => 'required'])); ?>

                            </div>
                            <div class="col">
                                <label for="sd_febril">Sd. Febril</label>
                                <?php echo e(Form::select('sd_febril', ['0' => 'No', '1' => 'Sí'], $antecedente ? $antecedente->sd_febril : old('sd_febril'), ['id' => 'sd_febril', 'class' => 'form-control', 'required' => 'required'])); ?>

                            </div>
                            <div class="col">
                                <label for="alergias">Alergias</label>
                                <?php echo e(Form::select('alergias', ['0' => 'No', '1' => 'Sí'], $antecedente ? $antecedente->alergias : old('alergias'), ['id' => 'alergias', 'class' => 'form-control', 'required' => 'required'])); ?>

                            </div>
                        </div>

                        <div class="mb-4 row">
                            <div class="col">
                                <label for="tuberculosis">Tuberculosis</label>
                                <?php echo e(Form::select('tuberculosis', ['0' => 'No', '1' => 'Sí'], $antecedente ? $antecedente->tuberculosis : old('tuberculosis'), ['id' => 'tuberculosis', 'class' => 'form-control', 'required' => 'required'])); ?>

                            </div>
                            <div class="col">
                                <label for="cirugias">Cirugías</label>
                                <?php echo e(Form::select('cirugias', ['0' => 'No', '1' => 'Sí'], $antecedente ? $antecedente->cirugias : old('cirugias'), ['id' => 'cirugias', 'class' => 'form-control', 'required' => 'required'])); ?>

                            </div>
                            <div class="col">
                                <label for="hip_arterial">Hipertensión arterial</label>
                                <?php echo e(Form::select('hip_arterial', ['0' => 'No', '1' => 'Sí'], $antecedente ? $antecedente->hip_arterial : old('hip_arterial'), ['id' => 'hip_arterial', 'class' => 'form-control', 'required' => 'required'])); ?>

                            </div>
                        </div>

                        <label style="font-weight: bold; color: black; font-size: 17px;">PATOLÓGICOS</label>

                        <div class="mb-4 row">
                            <div class="col">
                                <textarea id="patologicos" name="patologicos" type="text" class="form-control" placeholder="" required><?php echo e($antecedente ? $antecedente->patologicos : old('patologicos')); ?></textarea>
                            </div>
                        </div>

                        <label style="font-weight: bold; color: black; font-size: 17px;">FAMILIARES</label>

                        <div class="mb-4 row">
                            <div class="col">
                                <textarea id="familiares" name="familiares" type="text" class="form-control" placeholder="" required><?php echo e($antecedente ? $antecedente->familiares : old('familiares')); ?></textarea>
                            </div>
                        </div>

                        <label style="font-weight: bold; color: black; font-size: 17px;">OCUPACIONALES</label>

                        <div class="mb-4 row">
                            <div class="col">
                                <textarea id="ocupacionales" name="ocupacionales" type="text" class="form-control" placeholder="" required><?php echo e($antecedente ? $antecedente->ocupacionales : old('ocupacionales')); ?></textarea>
                            </div>
                        </div>

                        <div class="mb-4 row">
                            <div class="col">
                                <label for="ram">RAM</label>
                                <?php echo e(Form::select('ram', ['0' => 'No', '1' => 'Sí'], $antecedente ? $antecedente->ram : old('ram'), ['id' => 'ram', 'class' => 'form-control', 'required' => 'required'])); ?>

                            </div>
                        </div>

                        <div class="mb-4 row">
                            <div class="col">
                                <label for="ram_descripcion">RAM descripción</label>
                                <textarea id="ram_descripcion" name="ram_descripcion" type="text" class="form-control" placeholder=""><?php echo e($antecedente ? $antecedente->ram_descripcion : old('ram_descripcion')); ?></textarea>
                            </div>
                        </div>

                        <input type="submit" id="btnSubmit" class="btn btn-primary" value="Guardar">
                    </form>
                </div>

            </div>
        </div>
    </div>

    <div class="page-header">
        <div class="page-title">
            <h3>Listado de Citas</h3>
        </div>
        <a class="ml-3 btn btn-success" href="<?php echo e(route('citas.create', $patient_id)); ?>">Nueva Cita</a>
    </div>

    <div class="row layout-top-spacing layout-spacing">
        <div class="col-lg-12">
            <div class="statbox widget box box-shadow">
                <div class="widget-content widget-content-area">
                    <div class="mb-4 table-responsive">
                        <table id="style-2" class="table style-3 table-hover">
                            
                            <thead>
                                <tr>
                                    <th class="checkbox-column">Id</th>
                                    <th>Título</th>
                                    <th>Descripción</th>
                                    <th>Fecha</th>
                                    <th class="text-center">Acción</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                                            
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

     <?php $__env->slot('scripts', null, []); ?> 
        <script src="<?php echo e(asset('plugins/flatpickr/flatpickr.js')); ?>"></script>
        <script src="<?php echo e(asset('plugins/sweetalerts/sweetalert2.min.js')); ?>"></script>
        <script src="<?php echo e(asset('plugins/table/datatable/datatables.js')); ?>"></script>
        <script src="<?php echo e(asset('plugins/input-mask/jquery.inputmask.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('plugins/input-mask/input-mask.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/date-util.js')); ?>"></script>
        <script>

            $(function () {
                RegisterDeleteResultEvents();

                var f1 = flatpickr(document.getElementById('fecha_nacimiento'), {
                    maxDate: GetTodayDate()
                });

                CalculateAge('#fecha_nacimiento', '#edad');

                $("#correo_electronico").inputmask(
                    {
                        mask:"*{1,20}[.*{1,20}][.*{1,20}][.*{1,20}]@*{1,20}[.*{2,6}][.*{1,2}]",
                        greedy:!1,onBeforePaste:function(m,a){return(m=m.toLowerCase()).replace("mailto:","")},
                        definitions:{"*":
                            {
                                validator:"[0-9A-Za-z!#$%&'*+/=?^_`{|}~-]",
                                cardinality:1,
                                casing:"lower"
                            }
                        }
                    }
                );
            });

            $('#btnSubmit').click(function(e){
                e.preventDefault();
                if(this.form.reportValidity()){
                    $(this).prop('disabled',1);
                    // $(this).css('color', 'black');
                    this.style.setProperty( 'color', 'black', 'important' );
                    $(this).val('Guardando...');
                    this.form.submit();
                }
            });

            c2 = $('#style-2').DataTable({
                headerCallback:function(e, a, t, n, s) {
                    e.getElementsByTagName("th")[0].innerHTML='<label class="m-auto new-control new-checkbox checkbox-outline-primary">\n<input type="checkbox" class="new-control-input chk-parent select-customers-info" id="customer-all-info">\n<span class="new-control-indicator"></span><span style="visibility:hidden">c</span>\n</label>'
                },
                columnDefs:[ {
                    targets:0, width:"30px", className:"", orderable:!1, render:function(e, a, t, n) {
                        return'<label class="m-auto new-control new-checkbox checkbox-outline-primary">\n<input type="checkbox" class="new-control-input child-chk select-customers-info" id="customer-all-info">\n<span class="new-control-indicator"></span><span style="visibility:hidden">c</span>\n</label>'
                    }
                }],
                "oLanguage": {
                    "oPaginate": { "sPrevious": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-left"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>', "sNext": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-right"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>' },
                    "sInfo": "Mostrando página _PAGE_ de _PAGES_",
                    "sSearch": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>',
                    "sSearchPlaceholder": "Buscar...",
                "sLengthMenu": "Mostrar :  _MENU_",
                },
                "lengthMenu": [5, 10, 20, 50],
                "pageLength": 5
            });

            multiCheck(c2);

            function RegisterDeleteResultEvents() {
                $('.result_remove.confirm').on('click', function () {
                    let form_id = $(this).attr('form_id');
                    let result_title = $(this).attr('result_title');
                    swal({
                        title: `¿Está seguro de eliminar el resultado '${result_title}' ?`,
                        type: 'warning',
                        showCancelButton: 1,
                        cancelButtonText: "Cancelar",
                        confirmButtonText: 'Eliminar',
                        padding: '2em'
                    }).then(function(result) {
                        if (result.value) {
                            let form = $(`#${form_id}`);
                            form.submit();
                        }
                    });
                });
            }
        </script>
     <?php $__env->endSlot(); ?>

 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH F:\Web\Oscar\Clinica Reumatologica\historias\resources\views/patients/edit.blade.php ENDPATH**/ ?>