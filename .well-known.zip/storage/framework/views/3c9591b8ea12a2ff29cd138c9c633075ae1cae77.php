<!-- Modal -->
<div class="modal fade form-modal" id="paciente_import_csv" tabindex="-1" role="dialog" aria-labelledby="paciente_import_csv" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header" id="paciente_import_csv_Header">
                <h4 class="modal-title">Importar CSV</h4><br>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></button>
            </div>
            <div class="modal-body">
                <p>¡Atención! Esto puede durar varios minutos, ¡se recomienda un límite máximo de 300 entradas!</p>
                <form method="POST" class="mt-0" action="<?php echo e(route('patients.import')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <div class="form-group">
                        <label for="file">Archivo CSV</label>
                        <input type="file" class="form-control-file" id="file" name="file">
                        <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback" style="display: block;"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <button type="submit" class="mt-2 mb-2 btn btn-primary btn-block btn_submit">Importar</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<script>
    <?php if($errors->has('file')): ?>

        $(function() {
            $('#paciente_import_csv').modal({
                show: true
            });
        });

    <?php endif; ?>
</script>
<?php $__env->stopSection(); ?>
<?php /**PATH /home/uqyqosjr/historias.reumainnova.com/resources/views/patients/import_csv.blade.php ENDPATH**/ ?>