<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no">
    <title><?php echo e($title); ?></title>
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('assets/img/favicon.png')); ?>"/>
    <!-- BEGIN GLOBAL MANDATORY STYLES -->
    

    <style>
        @font-face {
            font-family: 'Mont';
            src: url('<?php echo e(asset("assets/fonts/Mont-Regular.woff")); ?>');
            font-weight: normal;
            font-style: normal;
        }

        @font-face {
            font-family: 'Mont';
            src: url('<?php echo e(asset("assets/fonts/Mont-Bold.woff")); ?>');
            font-weight: bold;
            font-style: normal;
        }

        @font-face {
            font-family: 'Mont';
            src: url('<?php echo e(asset("assets/fonts/Mont-RegularItalic.woff")); ?>');
            font-weight: normal;
            font-style: italic;
        }

        @font-face {
            font-family: 'Mont';
            src: url('<?php echo e(asset("assets/fonts/Mont-BoldItalic.woff")); ?>');
            font-weight: bold;
            font-style: italic;
        }
    </style>

    <link href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/css/plugins.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/css/structure.css')); ?>" rel="stylesheet" type="text/css" class="structure" />
    <link href="<?php echo e(asset('assets/css/authentication/form-1.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- END GLOBAL MANDATORY STYLES -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/forms/theme-checkbox-radio.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/forms/switches.css')); ?>">

    <?php echo e($styles ?? ''); ?>

</head>
<body class="form">


    <div class="form-container">
        <div class="form-form">
            <div class="form-form-wrap">
                <div class="form-container">
                    <div class="form-content">

                        <?php echo e($slot); ?>


                        <p class="terms-conditions">© <?php echo e(date('Y')); ?> Todos los derechos reservados. <br> <a href="">DMI</a>, Diagnóstico Médico por Imágenes.
                            
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <div class="form-image">
            <div class="l-image">
            </div>
        </div>
    </div>


    <!-- BEGIN GLOBAL MANDATORY SCRIPTS -->
    <script src="<?php echo e(asset('assets/js/libs/jquery-3.1.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bootstrap/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bootstrap/js/bootstrap.min.js')); ?>"></script>

    <!-- END GLOBAL MANDATORY SCRIPTS -->
    <script src="<?php echo e(asset('assets/js/authentication/form-1.js')); ?>"></script>

    <?php echo e($scripts ?? ''); ?>


</body>
</html>
<?php /**PATH F:\Web\DMI\online results\dmi-online-results-app\resources\views/components/layouts/auth.blade.php ENDPATH**/ ?>