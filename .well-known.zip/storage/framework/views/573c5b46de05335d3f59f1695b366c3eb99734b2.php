<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layouts.admin','data' => ['title' => 'DMI - Resultados en línea','bodyTitle' => 'Resultados en línea']]); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => 'DMI - Resultados en línea','bodyTitle' => 'Resultados en línea']); ?>

    <div class="ml-3 row layout-top-spacing">
        <h6>Bienvenid@ al sistema de Resultados en línea de DMI.</h6>
        
        <?php
            $user = Auth::user();
        ?>
        <?php if($user->user_role_id === 1 || $user->user_role_id === 2): ?>
            <a type="button" class="ml-3 btn btn-primary" href="<?php echo e(route('patients.all')); ?>">Buscar paciente</a>
        <?php elseif($user->user_role_id === 3): ?>
            <a type="button" class="ml-3 btn btn-primary" href="<?php echo e(route('results.all')); ?>">Ir a mis resultados</a>
        <?php endif; ?>
    </div>

 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH F:\Web\DMI\online results\dmi-online-results-app\resources\views/dashboard.blade.php ENDPATH**/ ?>