<!-- Modal -->
<?php if($tratamiento): ?>
    
<div class="modal fade form-modal" id="createModal" tabindex="-1" role="dialog" aria-labelledby="createModal" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header" id="createModalHeader">
                <h4 class="modal-title">Nuevo Medicamento</h4>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></button>
            </div>
            <div class="modal-body">
                <form method="POST" class="mt-0" action="<?php echo e(route('medicamentos.store', ['id'=>$tratamiento->id,'cita_id'=>$cita->id])); ?>">
                    <?php echo csrf_field(); ?>

                    <input type="hidden" id="create_modal_user_id" name="user_id" value="<?php echo e(old('user_id')); ?>">
                    <div class="form-group">
                        <label for="medicamento">Medicamento</label>
                        <input id="medicamento" type="text" class="mb-2 form-control" name="medicamento" placeholder="" required value="<?php echo e(old('medicamento')); ?>">
                        <?php $__errorArgs = ['medicamento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback" style="display: block;"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="concentracion">Concentración</label>
                        <input id="concentracion" type="text" class="mb-2 form-control" name="concentracion" placeholder="" required value="<?php echo e(old('concentracion')); ?>">
                        <?php $__errorArgs = ['concentracion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback" style="display: block;"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="dosis">Dosis</label>
                        <input id="dosis" type="text" class="mb-2 form-control" name="dosis" placeholder="" required value="<?php echo e(old('dosis')); ?>">
                        <?php $__errorArgs = ['dosis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback" style="display: block;"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="frecuencia">Frecuencia</label>
                        <input id="frecuencia" type="text" class="mb-2 form-control" name="frecuencia" placeholder="" required value="<?php echo e(old('frecuencia')); ?>">
                        <?php $__errorArgs = ['frecuencia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback" style="display: block;"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="via">Vía</label>
                        <?php echo e(Form::select('via', ['Oral' => 'Oral', 'Endovenosa' => 'Endovenosa', 'Intramuscular' => 'Intramuscular', 'Subcutáneo' => 'Subcutáneo', 'Rectal' => 'Rectal', 'Nasal' => 'Nasal', 'Ocular' => 'Ocular', 'Tópica' => 'Tópica'], old('via'), ['id' => 'via', 'class' => 'form-control', 'required' => 'required'])); ?>

                        
                        <?php $__errorArgs = ['via'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback" style="display: block;"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <button type="submit" id="btnCreateSubmit" class="mt-2 mb-2 btn btn-primary btn-block">Guardar</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php endif; ?>

<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<script>
    <?php if($errors->has('title') || $errors->has('description') || $errors->has('file')): ?>

        $(function() {
            $('#createModal').modal({
                show: true
            });
        });

    <?php endif; ?>

    $('#btnCreateSubmit').click(function(e){
        e.preventDefault();
        if(this.form.reportValidity()){
            $(this).prop('disabled',true);
            // $(this).css('color', 'black');
            // this.style.setProperty( 'color', 'black', 'important' );
            $(this).html('Guardando...');
            this.form.submit();
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php /**PATH F:\Web\Oscar\Clinica Reumatologica\historias\resources\views/medicamentos/create.blade.php ENDPATH**/ ?>