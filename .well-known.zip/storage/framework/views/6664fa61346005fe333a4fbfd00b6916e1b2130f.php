<?php echo e($slot); ?>

<?php /**PATH F:\Web\Oscar\Clinica Reumatologica\historias\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>