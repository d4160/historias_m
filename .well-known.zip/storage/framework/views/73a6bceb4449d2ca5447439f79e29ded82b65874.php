<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no">
    <title><?php echo e($title); ?></title>
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('assets/img/favicon.png')); ?>"/>
    <link href="<?php echo e(asset('assets/css/loader.css')); ?>" rel="stylesheet" type="text/css" />
    <script src="<?php echo e(asset('assets/js/loader.js')); ?>"></script>

    
    

    <style>
        @font-face {
            font-family: 'Mont';
            src: url('<?php echo e(asset("assets/fonts/Mont-Regular.woff")); ?>');
            font-weight: normal;
            font-style: normal;
        }

        @font-face {
            font-family: 'Mont';
            src: url('<?php echo e(asset("assets/fonts/Mont-Bold.woff")); ?>');
            font-weight: bold;
            font-style: normal;
        }

        @font-face {
            font-family: 'Mont';
            src: url('<?php echo e(asset("assets/fonts/Mont-RegularItalic.woff")); ?>');
            font-weight: normal;
            font-style: italic;
        }

        @font-face {
            font-family: 'Mont';
            src: url('<?php echo e(asset("assets/fonts/Mont-BoldItalic.woff")); ?>');
            font-weight: bold;
            font-style: italic;
        }
    </style>

    <link href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/css/plugins.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/css/structure.css')); ?>" rel="stylesheet" type="text/css" class="structure" />
    

    

    <?php echo e($styles ?? ''); ?>


    <?php echo $__env->yieldPushContent('styles'); ?>

    

</head>
<body class="sidebar-noneoverflow">

    
    <div id="load_screen"> <div class="loader"> <div class="loader-content">
        <div class="spinner-grow align-self-center"></div>
    </div></div></div>
    

    <?php
        $user = Auth::user();
    ?>

    
    <div class="header-container fixed-top">
        <header class="header navbar navbar-expand-sm">
            <ul class="flex-row navbar-item">
                <li class="nav-item theme-logo">
                    <a href="/">
                        <img src="<?php echo e(asset('assets/img/logo.png')); ?>" class="navbar-logo" alt="logo" style="height: auto; width: 112px">
                    </a>
                </li>
            </ul>

            <a href="javascript:void(0);" class="sidebarCollapse" data-placement="bottom"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-menu"><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg></a>

            <ul class="flex-row navbar-item search-ul">
                <li class="nav-item align-self-center search-animated">
                    
                </li>
            </ul>
            <ul class="flex-row navbar-item navbar-dropdown">

                <li class="order-1 nav-item dropdown user-profile-dropdown order-lg-0">
                    <a href="javascript:void(0);" class="nav-link dropdown-toggle user" id="userProfileDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <img src="<?php echo e(asset('assets/img/90x90.jpg')); ?>" alt="admin-profile" class="img-fluid">
                    </a>
                    <div class="dropdown-menu position-absolute animated fadeInUp" aria-labelledby="userProfileDropdown">
                        <div class="user-profile-section">
                            <div class="mx-auto media">
                                <img src="<?php echo e(asset('assets/img/90x90.jpg')); ?>" class="mr-2 img-fluid" alt="avatar">
                                <div class="media-body">
                                    <h5><?php echo e($user->first_names . ' ' . $user->last_names); ?></h5>
                                    <p>
                                        <?php switch($user->user_role_id):
                                            case (1): ?>
                                                Super Usuario
                                                <?php break; ?>
                                            <?php case (2): ?>
                                                Administrador
                                                <?php break; ?>
                                            <?php case (2): ?>
                                                Paciente
                                                <?php break; ?>
                                            <?php default: ?>
                                                Paciente
                                        <?php endswitch; ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                        
                        
                        
                        <div class="dropdown-item">
                            <form method="POST" action="<?php echo e(route('logout')); ?>">
                                <?php echo csrf_field(); ?>
                                <a href="" onclick="event.preventDefault();
                                                        this.closest('form').submit();">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-log-out"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg> <span><?php echo e(__('Logout')); ?></span>
                                </a>
                            </form>
                        </div>
                    </div>
                </li>
            </ul>
        </header>
    </div>
    

    <!--  BEGIN MAIN CONTAINER  -->
    <div class="main-container" id="container">

        <div class="overlay"></div>
        <div class="search-overlay"></div>

        
        <div class="sidebar-wrapper sidebar-theme">

            <nav id="compactSidebar">
                <ul class="menu-categories">

                    <?php if($user->user_role_id === 1 || $user->user_role_id === 2): ?>
                        <li class="menu active" >
                            <a href="#menu1" data-active="false" class="menu-toggle">
                                <div class="base-menu">
                                    <div class="base-icons">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-user"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                                    </div>
                                    <span>Pacientes</span>
                                </div>
                            </a>
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-left"><polyline points="15 18 9 12 15 6"></polyline></svg>
                        </li>
                    <?php elseif($user->user_role_id === 3): ?>
                        <li class="menu">
                            <a href="#menu2" data-active="true" class="menu-toggle">
                                <div class="base-menu">
                                    <div class="base-icons">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-file-text"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>
                                    </div>
                                    <span>Resultados <br>en línea</span>
                                </div>
                            </a>
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-left"><polyline points="15 18 9 12 15 6"></polyline></svg>
                        </li>
                    <?php endif; ?>

                    
                </ul>
            </nav>

            <div id="compact_submenuSidebar" class="submenu-sidebar">

                <div class="submenu" id="menu1">
                    <p><strong>Pacientes</strong></p>
                    <ul class="submenu-list" data-parent-element="#menu1">
                        <li>
                            <a href="<?php echo e(route('patients.all')); ?>">Todos los pacientes</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('patients.create')); ?>">Registrar nuevo</a>
                        </li>
                    </ul>
                </div>

                <div class="submenu" id="menu2">
                    <p><strong>Resultados en línea</strong></p>
                    <ul class="submenu-list" data-parent-element="#menu2">
                        <li>
                            <a href="<?php echo e(route('results.all')); ?>">Mis resultados</a>
                        </li>
                    </ul>
                </div>

                

                

                

            </div>

        </div>
        

        
        <div id="content" class="main-content">
            <div class="layout-px-spacing">

                <div class="page-header">
                    <div class="page-title">
                        <h3><?php echo e($bodyTitle); ?></h3>
                    </div>
                </div>

                

                <?php echo e($slot); ?>


                

            </div>
            <div class="footer-wrapper">
                <div class="footer-section f-section-1">
                    <p class="">Copyright © <?php echo e(date('Y')); ?> <a href="https://reumainnova.com">Reumainnova</a>, Todos los derechos reservados.</p>
                </div>
            </div>
        </div>
        

    </div>
    

    
    <script src="<?php echo e(asset('assets/js/libs/jquery-3.1.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bootstrap/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bootstrap/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/perfect-scrollbar/perfect-scrollbar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            App.init();
        });
    </script>
    <script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
    

    

    <?php echo e($scripts ?? ''); ?>


    <?php echo $__env->yieldPushContent('scripts'); ?>
    <?php echo $__env->yieldContent('scripts'); ?>

    
</body>
</html>
<?php /**PATH F:\Web\Oscar\Clinica Reumatologica\historias\resources\views/components/layouts/admin.blade.php ENDPATH**/ ?>