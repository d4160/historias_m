<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layouts.admin','data' => ['title' => 'Reumainnova - Nuevo paciente','bodyTitle' => 'Nuevo paciente']]); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => 'Reumainnova - Nuevo paciente','bodyTitle' => 'Nuevo paciente']); ?>
     <?php $__env->slot('styles', null, []); ?> 
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('plugins/table/datatable/datatables.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/forms/theme-checkbox-radio.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('plugins/table/datatable/dt-global_style.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('plugins/table/datatable/custom_dt_custom.css')); ?>">
        <link href="<?php echo e(asset('plugins/flatpickr/flatpickr.css')); ?>" rel="stylesheet" type="text/css">

        <?php echo \Livewire\Livewire::styles(); ?>

     <?php $__env->endSlot(); ?>

    <div class="row layout-top-spacing layout-spacing">
        <div class="col-lg-12">
            <div class="statbox widget box box-shadow">

                <div class="widget-header">

                    <!-- Validation Errors -->
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.auth-validation-errors','data' => ['class' => 'm-4','errors' => $errors]]); ?>
<?php $component->withName('auth-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'm-4','errors' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                    <form class="m-3 mt-4 mb-4" method="POST" action="<?php echo e(route('patients.store')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="mb-4 row">
                            <div class="col">
                                <label for="num_document">DNI o CE</label>
                                <input id="num_document" name="num_document" type="text" class="form-control" placeholder="77777777" value="<?php echo e(old('num_document')); ?>" required autofocus minlength="8" maxlength="11">
                            </div>
                            <div class="col">
                                <label for="next_id">Código de paciente</label>
                                <input id="next_id" name="next_id" type="text" class="form-control" placeholder="" value="<?php (printf("%06d", $paciente_next_id)); ?>" readonly>
                            </div>
                            
                        </div>
                        <div class="mb-4 row">
                            <div class="col">
                                <label for="first_names">Nombres</label>
                                <input id="first_names" name="first_names" type="text" class="form-control" placeholder="" value="<?php echo e(old('first_names')); ?>" required>
                            </div>
                            <div class="col">
                                <label for="last_names">Apellidos</label>
                                <input id="last_names" name="last_names" type="text" class="form-control" placeholder="" value="<?php echo e(old('last_names')); ?>" required>
                            </div>
                        </div>

                        <div class="mb-4 row">
                            <div class="col">
                                <label for="sexo">Sexo</label>
                                <?php echo e(Form::select('sexo', ['M (Masculino)' => 'M (Masculino)', 'F (Femenino)' => 'F (Femenino)'], old('sexo'), ['id' => 'sexo', 'class' => 'form-control', 'required' => 'required'])); ?>

                            </div>
                            <div class="col">
                                <label for="estado_civil">Estado Civil</label>
                                <?php echo e(Form::select('estado_civil', ['S (Soltero)' => 'S (Soltero)', 'C (Casado)' => 'C (Casado)', 'Co (Conviviente)' => 'Co (Conviviente)', 'D (Divorciado)' => 'D (Divorciado)', 'V (Viudo)' => 'V (Viudo)'], old('estado_civil'), ['id' => 'estado_civil', 'class' => 'form-control', 'required' => 'required'])); ?>

                            </div>
                        </div>

                        <div class="mb-4 row">
                            <div class="col">
                                <label for="raza">Raza</label>
                                <?php echo e(Form::select('raza', ['India' => 'India', 'Española' => 'Española', 'Negra' => 'Negra', 'China' => 'China', 'Mestiza' => 'Mestiza', 'Otra' => 'Otra'], old('raza', 'Mestiza'), ['id' => 'raza', 'class' => 'form-control', 'required' => 'required'])); ?>

                            </div>
                            <div class="col">
                                <label for="religion">Religión</label>
                                <?php echo e(Form::select('religion', ['Católica' => 'Católica', 'Evangélica' => 'Evangélica', 'Cristiana' => 'Cristiana', 'Agnóstica' => 'Agnóstica', 'Atea' => 'Atea', 'Otra' => 'Otra'], old('religion', 'Cristiana'), ['id' => 'religion', 'class' => 'form-control', 'required' => 'required'])); ?>

                            </div>
                        </div>

                        <div class="mb-4 row">
                            <div class="col">
                                <label for="fecha_nacimiento">Fecha de nacimiento</label>
                                <input id="fecha_nacimiento" name="fecha_nacimiento" value="<?php echo e(old('fecha_nacimiento')); ?>" class="form-control" type="text" placeholder="" readonly="readonly" required>
                            </div>
                            <div class="col">
                                <label for="edad">Edad</label>
                                <input id="edad" name="edad" type="text" class="form-control" placeholder="" value="" readonly required>
                            </div>
                        </div>

                        <div class="mb-4 row">
                            <div class="col">
                                <label for="lugar_nac">Lugar de nacimiento</label>
                                <input id="lugar_nac" name="lugar_nac" type="text" class="form-control" placeholder="" value="<?php echo e(old('lugar_nac')); ?>">
                            </div>
                        </div>

                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('procedencia', [])->html();
} elseif ($_instance->childHasBeenRendered('vjJ7A47')) {
    $componentId = $_instance->getRenderedChildComponentId('vjJ7A47');
    $componentTag = $_instance->getRenderedChildComponentTagName('vjJ7A47');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('vjJ7A47');
} else {
    $response = \Livewire\Livewire::mount('procedencia', []);
    $html = $response->html();
    $_instance->logRenderedChild('vjJ7A47', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                        <div class="mb-4 row">
                            <div class="col">
                                <label for="direccion_actual">Dirección actual</label>
                                <input id="direccion_actual" name="direccion_actual" type="text" class="form-control" placeholder="" value="<?php echo e(old('direccion_actual')); ?>" required>
                            </div>
                        </div>

                        <div class="mb-4 row">
                            <div class="col">
                                <label for="grado_inst_ocu">Grado de instrucción/ocupación</label>
                                <?php echo e(Form::select('grado_inst_ocu', ['Estudiante primaria' => 'Estudiante primaria', 'Estudiante segundaria' => 'Estudiante segundaria', 'Estudiante técnico' => 'Estudiante técnico', 'Estudiante universitario' => 'Estudiante universitario', 'Independiente' => 'Independiente', 'Dependiente' => 'Dependiente'], old('grado_inst_ocu'), ['id' => 'grado_inst_ocu', 'class' => 'form-control', 'required' => 'required'])); ?>

                            </div>
                            <div class="col">
                                <label for="centro_edu_lab">Centro educativo/laboral</label>
                                <input id="centro_edu_lab" name="centro_edu_lab" type="text" class="form-control" placeholder="" value="<?php echo e(old('centro_edu_lab')); ?>">
                            </div>
                        </div>

                        <div class="mb-4 row">
                            <div class="col">
                                <label for="grupo_sanguineo">Grupo sanguíneo</label>
                                <select id="grupo_sanguineo" name="grupo_sanguineo" class="form-control" value="<?php echo e(old('grupo_sanguineo')); ?>" required>
                                    <option>O</option>
                                    <option>A</option>
                                    <option>AB</option>
                                    <option>B</option>
                                    <option>NR</option>
                                </select>
                            </div>
                            <div class="col">
                                <label for="factor_rh">Factor Rh</label>
                                <select id="factor_rh" name="factor_rh" value="<?php echo e(old('factor_rh')); ?>" class="form-control" required>
                                    <option>+</option>
                                    <option>-</option>
                                    <option>NR</option>
                                </select>
                            </div>
                        </div>

                        <div class="mb-4 row">
                            <div class="col">
                                <label for="telefono_fijo">Teléfono fijo</label>
                                <input id="telefono_fijo" name="telefono_fijo" type="text" class="form-control" placeholder="" value="<?php echo e(old('telefono_fijo')); ?>">
                            </div>
                            <div class="col">
                                <label for="celular">Celular</label>
                                <input id="celular" name="celular" type="text" class="form-control" placeholder="" value="<?php echo e(old('celular')); ?>">
                            </div>
                        </div>

                        <div class="mb-4 row">
                            <div class="col">
                                <label for="email">Correo Electrónico</label>
                                <input id="email" name="email" type="text" class="form-control" placeholder="" value="<?php echo e(old('email')); ?>">
                            </div>
                        </div>

                        <input type="submit" id="btnSubmit" onclick="" class="btn btn-primary" value="Guardar">
                    </form>
                </div>
            </div>
        </div>
    </div>

     <?php $__env->slot('scripts', null, []); ?> 
        <script src="<?php echo e(asset('plugins/flatpickr/flatpickr.js')); ?>"></script>
        <script src="<?php echo e(asset('plugins/input-mask/jquery.inputmask.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('plugins/input-mask/input-mask.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/date-util.js')); ?>"></script>
        <script>
            $(() => {
                var f1 = flatpickr(document.getElementById('fecha_nacimiento'), {
                    maxDate: GetTodayDate()
                });

                $("#correo_electronico").inputmask(
                    {
                        mask:"*{1,20}[.*{1,20}][.*{1,20}][.*{1,20}]@*{1,20}[.*{2,6}][.*{1,2}]",
                        greedy:!1,onBeforePaste:function(m,a){return(m=m.toLowerCase()).replace("mailto:","")},
                        definitions:{"*":
                            {
                                validator:"[0-9A-Za-z!#$%&'*+/=?^_`{|}~-]",
                                cardinality:1,
                                casing:"lower"
                            }
                        }
                    }
                )
            });

            $('#btnSubmit').click(function(e){
                e.preventDefault();
                if(this.form.reportValidity()){
                    $(this).prop('disabled',true);
                    this.style.setProperty( 'color', 'black', 'important' );
                    $(this).val('Guardando...');
                    this.form.submit();
                }
            });

            CalculateAge('#fecha_nacimiento', '#edad');

        </script>

        <?php echo \Livewire\Livewire::scripts(); ?>

     <?php $__env->endSlot(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH F:\Web\Oscar\Clinica Reumatologica\historias\resources\views/patients/create.blade.php ENDPATH**/ ?>