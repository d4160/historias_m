<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layouts.admin','data' => ['title' => 'Reumainnova - Historias Clínicas','bodyTitle' => 'Historias Clínicas']]); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => 'Reumainnova - Historias Clínicas','bodyTitle' => 'Historias Clínicas']); ?>

    <?php
        $user = Auth::user();
    ?>

    <div class="ml-3 layout-top-spacing">
        <h6>Hola <?php echo e($user->full_name); ?>,</h6>
        <p>Bienvenid@ al sistema de Historias Clínicas de Reumainnova.</p>
        <br>
        <?php
            $user = Auth::user();
        ?>
        <?php if($user->user_role_id > 0 && $user->user_role_id < 5): ?>
            <p><strong>Rol</strong>: Administrador</p>
            <a type="button" class="ml-3 btn btn-primary" href="<?php echo e(route('patients.all')); ?>">Buscar paciente</a>
        <?php elseif($user->user_role_id === 5): ?>
            <p><strong>Rol</strong>: Paciente</p>
            <a type="button" class="ml-3 btn btn-primary" href="<?php echo e(route('results.all')); ?>">Ir a mis resultados</a>
        <?php endif; ?>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH /home/uqyqosjr/historias.reumainnova.com/resources/views/dashboard.blade.php ENDPATH**/ ?>