<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layouts.admin','data' => ['title' => 'DMI - Nuevo paciente','bodyTitle' => 'Nuevo paciente']]); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => 'DMI - Nuevo paciente','bodyTitle' => 'Nuevo paciente']); ?>
     <?php $__env->slot('styles', null, []); ?> 
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('plugins/table/datatable/datatables.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/forms/theme-checkbox-radio.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('plugins/table/datatable/dt-global_style.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('plugins/table/datatable/custom_dt_custom.css')); ?>">
     <?php $__env->endSlot(); ?>

    <div class="row layout-top-spacing layout-spacing">
        <div class="col-lg-12">
            <div class="statbox widget box box-shadow">

                <div class="widget-header">

                    <!-- Validation Errors -->
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.auth-validation-errors','data' => ['class' => 'm-4','errors' => $errors]]); ?>
<?php $component->withName('auth-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'm-4','errors' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

                    <form class="m-3 mt-4 mb-4" method="POST" action="<?php echo e(route('patients.store')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="mb-4 row">
                            <div class="col">
                                <label for="num_document">Nº documento</label>
                                <input id="num_document" name="num_document" type="text" class="form-control" placeholder="77777777" value="<?php echo e(old('num_document')); ?>" required autofocus minlength="8" maxlength="11">
                            </div>
                            <div class="col">
                                <label for="num_document_confirmation">Confirme Nº documento</label>
                                <input id="num_document_confirmation" name="num_document_confirmation" type="text" class="form-control" placeholder="" value="<?php echo e(old('num_document_confirmation')); ?>" required minlength="8" maxlength="11">
                            </div>
                        </div>
                        <div class="mb-4 row">
                            <div class="col">
                                <label for="first_names">Nombres</label>
                                <input id="first_names" name="first_names" type="text" class="form-control" placeholder="" value="<?php echo e(old('first_names')); ?>" required>
                            </div>
                            <div class="col">
                                <label for="last_names">Apellidos</label>
                                <input id="last_names" name="last_names" type="text" class="form-control" placeholder="" value="<?php echo e(old('last_names')); ?>" required>
                            </div>
                        </div>
                        <input type="submit" id="btnSubmit" onclick="" class="btn btn-primary" value="Guardar">
                    </form>
                </div>
            </div>
        </div>
    </div>

     <?php $__env->slot('scripts', null, []); ?> 
        <script>
            $('#btnSubmit').click(function(e){
                e.preventDefault();
                if(this.form.reportValidity()){
                    $(this).prop('disabled',true);
                    $(this).val('Guardando...');
                    this.form.submit();
                }
            });
        </script>
     <?php $__env->endSlot(); ?>

 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH D:\Program Files\xampp\htdocs\laravel\resources\views/patients/create.blade.php ENDPATH**/ ?>