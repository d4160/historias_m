<?php return array (
  'anamnesis' => 'App\\Http\\Livewire\\Anamnesis',
  'antecedente' => 'App\\Http\\Livewire\\Antecedente',
  'examen-clinico' => 'App\\Http\\Livewire\\ExamenClinico',
  'examen-regional' => 'App\\Http\\Livewire\\ExamenRegional',
  'impresion-diagnostica' => 'App\\Http\\Livewire\\ImpresionDiagnostica',
  'procedencia' => 'App\\Http\\Livewire\\Procedencia',
  'tratamiento' => 'App\\Http\\Livewire\\Tratamiento',
);