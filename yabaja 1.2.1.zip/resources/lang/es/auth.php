<?php

return [
    'failed'   => 'Estas credenciales no coinciden con nuestros registros.',
    'password' => 'La contraseña ingresada no es correcta.',
    'throttle' => 'Demasiados intentos de acceso. Por favor intente nuevamente en :seconds segundos.',
];
