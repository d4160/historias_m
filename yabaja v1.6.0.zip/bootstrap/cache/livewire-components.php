<?php return array (
  'anamnesis' => 'App\\Http\\Livewire\\Anamnesis',
  'antecedente' => 'App\\Http\\Livewire\\Antecedente',
  'cita' => 'App\\Http\\Livewire\\Cita',
  'citas' => 'App\\Http\\Livewire\\Citas',
  'documento' => 'App\\Http\\Livewire\\Documento',
  'examen-clinico' => 'App\\Http\\Livewire\\ExamenClinico',
  'examen-regional' => 'App\\Http\\Livewire\\ExamenRegional',
  'historias' => 'App\\Http\\Livewire\\Historias',
  'impresion-diagnostica' => 'App\\Http\\Livewire\\ImpresionDiagnostica',
  'kardex' => 'App\\Http\\Livewire\\Kardex',
  'procedencia' => 'App\\Http\\Livewire\\Procedencia',
  'tratamiento' => 'App\\Http\\Livewire\\Tratamiento',
);