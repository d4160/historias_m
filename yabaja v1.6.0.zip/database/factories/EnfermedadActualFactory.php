<?php

namespace Database\Factories;

use App\Models\EnfermedadActual;
use Illuminate\Database\Eloquent\Factories\Factory;

class EnfermedadActualFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = EnfermedadActual::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
