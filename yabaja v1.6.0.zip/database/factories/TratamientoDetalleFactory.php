<?php

namespace Database\Factories;

use App\Models\TratamientoDetalle;
use Illuminate\Database\Eloquent\Factories\Factory;

class TratamientoDetalleFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = TratamientoDetalle::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
